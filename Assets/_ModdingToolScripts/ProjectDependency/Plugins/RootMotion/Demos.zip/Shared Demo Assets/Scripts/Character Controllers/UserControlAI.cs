﻿using UnityEngine;

namespace RootMotion.Demos
{
	/// <summary>
	///     User input for an AI controlled character controller.
	/// </summary>
	public class UserControlAI : UserControlThirdPerson
    {
        public Transform moveTarget;
        public Navigator navigator;
        public float stoppingDistance = 0.5f;
        public float stoppingThreshold = 1.5f;

        protected override void Start()
        {
            base.Start();

            navigator.Initiate(transform);
        }

        protected override void Update()
        {
            var moveSpeed = walkByDefault ? 0.5f : 1f;

            // If using Unity Navigation
            if (navigator.activeTargetSeeking)
            {
                navigator.Update(moveTarget.position);
                state.move = navigator.normalizedDeltaPosition * moveSpeed;
            }
            // No navigation, just move straight to the target
            else
            {
                var direction = moveTarget.position - transform.position;
                var distance = direction.magnitude;

                var normal = transform.up;
                Vector3.OrthoNormalize(ref normal, ref direction);

                var sD = state.move != Vector3.zero ? stoppingDistance : stoppingDistance * stoppingThreshold;

                state.move = distance > sD ? direction * moveSpeed : Vector3.zero;
                state.lookPos = moveTarget.position;
            }
        }

        // Visualize the navigator
        private void OnDrawGizmos()
        {
            if (navigator.activeTargetSeeking) navigator.Visualize();
        }
    }
}