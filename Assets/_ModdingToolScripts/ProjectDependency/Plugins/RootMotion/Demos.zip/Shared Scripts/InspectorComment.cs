﻿using UnityEngine;

namespace RootMotion
{
    /// <summary>
    ///     Comment attribute for Editor.
    /// </summary>
    public class InspectorComment : PropertyAttribute
    {
        public string color = "white";

        public string name;

        public InspectorComment(string name)
        {
            this.name = name;
            color = "white";
        }

        public InspectorComment(string name, string color)
        {
            this.name = name;
            this.color = color;
        }
    }
}