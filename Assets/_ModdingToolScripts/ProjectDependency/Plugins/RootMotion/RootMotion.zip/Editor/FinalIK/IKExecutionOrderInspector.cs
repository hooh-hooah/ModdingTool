﻿using UnityEditor;
using UnityEngine;

namespace RootMotion.FinalIK
{
    // Custom inspector for IKExecutionOrder
    [CustomEditor(typeof(IKExecutionOrder))]
    public class IKExecutionOrderInspector : Editor
    {
        private MonoScript monoScript;

        private IKExecutionOrder script => target as IKExecutionOrder;

        private void OnEnable()
        {
            if (serializedObject == null) return;

            // Changing the script execution order
            if (!Application.isPlaying)
            {
                var executionOrder = 9996;
                monoScript = MonoScript.FromMonoBehaviour(script);
                var currentExecutionOrder = MonoImporter.GetExecutionOrder(monoScript);
                if (currentExecutionOrder != executionOrder) MonoImporter.SetExecutionOrder(monoScript, executionOrder);
            }
        }
    }
}